"use client";
import { useEffect, useState } from "react";
import ProductCard from "@/components/ProductCard";
import { useCart } from "../components/cart/store";
import { Filter, ChevronDown, ShoppingCart, ArrowUp } from "lucide-react";

type Product = { 
  id: number; 
  name: string; 
  price: string | number; 
  images?: {src: string}[]; 
  categories?: {id: number; name: string}[];
  stock_status?: string;
  weight?: string;
  sale_price?: number | null;
  regular_price?: number;
};

type Category = {
  id: number;
  name: string;
  count?: number;
};

const CATEGORY_TRANSLATIONS = {
  'Misc': 'Разное',
  'Supplements': 'Пищевые добавки', 
  'Vitamins': 'Витамины',
  'Minerals': 'Минералы',
  'Antioxidants': 'Антиоксиданты',
  'Proteins': 'Белки',
  'Herbs': 'Травы'
};

const formatPrice = (price: number): string => {
  if (price === 0) return 'Уточнить цену';
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(price).replace('₽', '').trim() + ' ₽';
};

const translateCategory = (name: string): string => {
  return CATEGORY_TRANSLATIONS[name as keyof typeof CATEGORY_TRANSLATIONS] || name;
};

export default function CatalogPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<number | undefined>(undefined);
  const [mounted, setMounted] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState('popularity');
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const cart = useCart();

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => { 
    if (!mounted) return;
    
    let isCancelled = false;
    
    (async () => {
      try {
        setLoading(true);
        setError(null);
        
        const [productsResponse, categoriesResponse] = await Promise.all([
          fetch("/api/products", {
            method: "GET",
            headers: { "Content-Type": "application/json" }
          }),
          fetch("/api/categories", {
            method: "GET", 
            headers: { "Content-Type": "application/json" }
          })
        ]);

        if (isCancelled) return;

        if (!productsResponse.ok) {
          throw new Error(`Products API failed: ${productsResponse.status}`);
        }

        if (!categoriesResponse.ok) {
          throw new Error(`Categories API failed: ${categoriesResponse.status}`);
        }

        const productsData = await productsResponse.json();
        const categoriesData = await categoriesResponse.json();

        if (isCancelled) return;

        const processedProducts = productsData.map((p: any) => ({
          ...p,
          price: typeof p.price === "string" ? parseFloat(p.price) || 0 : p.price
        }));

        // Add product counts to categories
        const categoriesWithCounts = categoriesData.map((cat: Category) => ({
          ...cat,
          name: translateCategory(cat.name),
          count: processedProducts.filter((p: Product) => 
            p.categories?.some(c => c.id === cat.id)
          ).length
        }));

        setProducts(processedProducts);
        setCategories(categoriesWithCounts);
        
      } catch (err) {
        if (isCancelled) return;
        console.error("Loading error:", err);
        setError(err instanceof Error ? err.message : "Unknown error");
      } finally {
        if (!isCancelled) {
          setLoading(false);
        }
      }
    })();

    return () => {
      isCancelled = true;
    };
  }, [mounted]);


  const filteredProducts = (() => {
    let result = products.filter(p => {
      const okCat = selectedCategory ? p.categories?.some(c => c.id === selectedCategory) : true;
      return okCat;
    });

    // Sort products
    switch (sortBy) {
      case 'price-asc':
        result.sort((a, b) => (a.price as number) - (b.price as number));
        break;
      case 'price-desc':
        result.sort((a, b) => (b.price as number) - (a.price as number));
        break;
      case 'name':
        result.sort((a, b) => a.name.localeCompare(b.name));
        break;
      default: // popularity
        break;
    }

    return result;
  })();

  const getCurrentCategoryPath = () => {
    if (!selectedCategory) return 'Все товары';
    const category = categories.find(c => c.id === selectedCategory);
    return category ? category.name : 'Все товары';
  };

  if (!mounted) {
    return (
      <div className="telegram-app">
        <div className="telegram-loading">
          <div className="telegram-loader">Загрузка...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="telegram-app telegram-catalog-page">
      {/* Header */}
      <div className="telegram-catalog-header">
        <h1 className="telegram-page-title">{getCurrentCategoryPath()}</h1>
        <div className="telegram-header-actions">
          <button 
            onClick={() => setShowFilters(true)}
            className="telegram-filter-button"
          >
            <Filter className="telegram-filter-icon" />
            Фильтры
          </button>
        </div>
      </div>

      {/* Sticky Category Filters */}
      <div className="telegram-category-sticky">
        <div className="telegram-category-scroll">
          <button 
            onClick={() => setSelectedCategory(undefined)}
            className={`telegram-category-chip ${!selectedCategory ? "telegram-category-active" : ""}`}
            aria-pressed={!selectedCategory}
          >
            Все товары
          </button>
          {categories.slice(0, 6).map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`telegram-category-chip ${selectedCategory === cat.id ? "telegram-category-active" : ""}`}
              aria-pressed={selectedCategory === cat.id}
            >
              {cat.name} · {cat.count}
            </button>
          ))}
        </div>
      </div>

      {/* Sort Options */}
      <div className="telegram-sort-container">
        <button className="telegram-sort-button" onClick={() => setShowFilters(true)}>
          <span>Сортировать: {
            sortBy === 'popularity' ? 'по популярности' :
            sortBy === 'price-asc' ? 'по возрастанию цены' :
            sortBy === 'price-desc' ? 'по убыванию цены' :
            'по названию'
          }</span>
          <ChevronDown className="telegram-sort-icon" />
        </button>
      </div>

      {/* Products Grid */}
      {loading ? (
        <div className="telegram-products-grid">
          {Array.from({length: 6}).map((_, i) => (
            <div key={i} className="telegram-product-skeleton">
              <div className="telegram-skeleton-image"></div>
              <div className="telegram-skeleton-price"></div>
              <div className="telegram-skeleton-title"></div>
              <div className="telegram-skeleton-chips">
                <div className="telegram-skeleton-chip"></div>
                <div className="telegram-skeleton-chip"></div>
              </div>
              <div className="telegram-skeleton-button"></div>
            </div>
          ))}
        </div>
      ) : error ? (
        <div className="telegram-error">
          <div className="telegram-error-icon">⚠️</div>
          <div className="telegram-error-text">Ошибка загрузки</div>
          <div className="telegram-error-message">{error}</div>
          <button 
            onClick={() => window.location.reload()}
            className="telegram-retry-btn"
          >
            Попробовать снова
          </button>
        </div>
      ) : (
        <>
          <div className="telegram-products-grid" aria-busy={loading}>
            {filteredProducts.map((product) => (
              <EnhancedProductCard 
                key={product.id} 
                product={product} 
                onAddToCart={cart.add}
              />
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="telegram-empty-state">
              <div className="telegram-empty-icon">📦</div>
              <div className="telegram-empty-text">Товары не найдены</div>
              <div className="telegram-empty-hint">Попробуйте изменить фильтры</div>
            </div>
          )}
        </>
      )}

      {/* Sticky Bottom Cart Bar */}
      <a href="/cart" className="telegram-sticky-cart-bar">
        <div className="telegram-cart-summary">
          <div className="telegram-cart-info">
            <ShoppingCart className="telegram-cart-bar-icon" />
            <span className="telegram-cart-count">{cart.count()} товаров</span>
            <span className="telegram-cart.total()">{formatPrice(cart.total())}</span>
          </div>
          <button 
            className="telegram-cart-button"
            disabled={cart.count() === 0}
          >
            К оформлению
          </button>
        </div>
      </a>

      {/* Filter Modal */}
      {showFilters && (
        <div className="telegram-modal-overlay">
          <div className="telegram-filter-modal">
            <div className="telegram-filter-header">
              <h3 className="telegram-filter-title">Фильтры и сортировка</h3>
              <button
                onClick={() => setShowFilters(false)}
                className="telegram-filter-close"
              >
                ×
              </button>
            </div>
            
            <div className="telegram-filter-content">
              <div className="telegram-filter-section">
                <h4 className="telegram-filter-section-title">Сортировка</h4>
                <div className="telegram-sort-options">
                  {[
                    { value: 'popularity', label: 'По популярности' },
                    { value: 'price-asc', label: 'Сначала дешевые' },
                    { value: 'price-desc', label: 'Сначала дорогие' },
                    { value: 'name', label: 'По названию' }
                  ].map(option => (
                    <button
                      key={option.value}
                      onClick={() => setSortBy(option.value)}
                      className={`telegram-sort-option ${sortBy === option.value ? 'active' : ''}`}
                    >
                      {option.label}
                      {sortBy === option.value && <span className="telegram-check">✓</span>}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="telegram-filter-actions">
              <button
                onClick={() => setShowFilters(false)}
                className="telegram-filter-apply"
              >
                Применить
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Enhanced Product Card Component
function EnhancedProductCard({ 
  product, 
  onAddToCart 
}: { 
  product: Product; 
  onAddToCart: (product: any, qty?: number) => Promise<void> 
}) {
  const [isLoading, setIsLoading] = useState(false);

  const price = typeof product.price === "string" ? parseFloat(product.price) : product.price;
  const isOnSale = product.sale_price && product.sale_price < (product.regular_price || price);
  const discount = isOnSale ? Math.round(((product.regular_price! - product.sale_price!) / product.regular_price!) * 100) : 0;

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    try {
      setIsLoading(true);
      await onAddToCart({
        id: product.id,
        name: product.name,
        price: price,
        image: product.images?.[0]?.src
      }, 1);
    } catch (error) {
      console.error("Failed to add to cart:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCardClick = () => {
    window.location.href = `/product/${product.id}`;
  };

  return (
    <div 
      onClick={handleCardClick}
      className="telegram-enhanced-card"
    >
      {/* Discount Badge */}
      {isOnSale && discount > 0 && (
        <div className="telegram-discount-corner">
          -{discount}%
        </div>
      )}

      {/* Product Image */}
      <div className="telegram-enhanced-image-container">
        {product.images?.[0]?.src ? (
          <img
            src={product.images[0].src}
            alt={product.name}
            className="telegram-enhanced-image"
            loading="lazy"
          />
        ) : (
          <div className="telegram-enhanced-no-image">
            <span>🖼️</span>
          </div>
        )}
      </div>

      {/* Price */}
      <div className="telegram-enhanced-price-container">
        <span className="telegram-enhanced-price">
          {formatPrice(price)}
        </span>
        {product.price === 0 && (
          <div className="telegram-price-tooltip">
            <span>Цена обновляется</span>
          </div>
        )}
      </div>

      {/* Product Name */}
      <h3 className="telegram-enhanced-title">
        {product.name}
      </h3>

      {/* Product Info Chips */}
      <div className="telegram-enhanced-chips">
        {product.stock_status === 'instock' && (
          <span className="telegram-info-chip telegram-stock-chip">В наличии</span>
        )}
        {product.weight && (
          <span className="telegram-info-chip telegram-weight-chip">{product.weight}</span>
        )}
      </div>

      {/* Add to Cart Button */}
      <button
        onClick={handleAddToCart}
        disabled={isLoading || price === 0}
        className="telegram-enhanced-cart-btn"
      >
        {isLoading ? "Добавляем..." : price === 0 ? "Уточнить" : "В корзину"}
      </button>
    </div>
  );
}
