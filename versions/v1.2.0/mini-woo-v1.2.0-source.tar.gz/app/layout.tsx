import { ReactNode } from 'react';
import Script from 'next/script';
import './globals.css';
import './mobile-styles.css';
import ClientLayout from './client-layout';
import type { Metadata, Viewport } from 'next';

export const metadata: Metadata = {
  title: 'Mini Woo Store',
  description: 'Telegram Mini App for WooCommerce Store',
  formatDetection: {
    telephone: false
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'Mini Woo Store'
  }
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: '#007aff'
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body className="min-h-screen telegram-app">
        <Script 
          src="https://telegram.org/js/telegram-web-app.js" 
          strategy="beforeInteractive"
        />
        <ClientLayout>
          {children}
        </ClientLayout>
      </body>
    </html>
  );
}
